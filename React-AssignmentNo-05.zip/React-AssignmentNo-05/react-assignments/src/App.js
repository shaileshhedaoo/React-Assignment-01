import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import About from "./Assignment-05/components/About";
import ProductsList from "./Assignment-05/components/ProductsList";

const App = () => {
  return (
    <Router>
      <div>
        <nav>
          <Link to="/">About</Link> | <Link to="/products">Products</Link>
        </nav>
        <Routes>
          <Route path="/" element={<About />} />
          <Route path="/products" element={<ProductsList />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
