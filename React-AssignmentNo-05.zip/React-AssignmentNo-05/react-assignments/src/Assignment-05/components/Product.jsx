import React from "react";

const Product = ({ product }) => {
  const { productName, quantity, price } = product;

  const cardStyle = {
    border: "1px solid #ddd",
    borderRadius: "8px",
    padding: "20px",
    width: "250px",
    textAlign: "center",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    backgroundColor: "#f9f9f9",
  };

  const headingStyle = {
    fontSize: "1.2rem",
    color: "#444",
    marginBottom: "10px",
  };

  const textStyle = {
    fontSize: "1rem",
    color: "#666",
    marginBottom: "8px",
  };

  return (
    <div style={cardStyle}>
      <h2 style={headingStyle}>{productName}</h2>
      <p style={textStyle}>Quantity: {quantity}</p>
      <p style={textStyle}>Price: ${price}</p>
    </div>
  );
};

export default Product;
