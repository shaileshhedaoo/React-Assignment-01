import React from "react";

const About = () => {
  return (
    <div>
      <h1>About (Using Functional Componant):- This Application provides the infomation about the products. </h1>
    </div>
  );
};

export default About;
