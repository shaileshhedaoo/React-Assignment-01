import React, { useState, useEffect } from "react";
import axios from "axios";

const ProductsList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch products from the backend server
    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:5173/products");
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []); // Empty dependency array ensures this runs only once

  if (loading) {
    return (
      <p
        style={{
          fontSize: "1.5rem",
          color: "gray",
          textAlign: "center",
          marginTop: "50px",
        }}
      >
        Loading products...
      </p>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ textAlign: "center", color: "#333", marginBottom: "20px" }}>
        Products
      </h1>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: "20px",
        }}
      >
        <thead>
          <tr style={{ backgroundColor: "#f4f4f4" }}>
            <th style={tableHeaderStyle}>ID</th>
            <th style={tableHeaderStyle}>Product Name</th>
            <th style={tableHeaderStyle}>Quantity</th>
            <th style={tableHeaderStyle}>Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td style={tableCellStyle}>{product.id}</td>
              <td style={tableCellStyle}>{product.productName}</td>
              <td style={tableCellStyle}>{product.quantity}</td>
              <td style={tableCellStyle}>${product.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const tableHeaderStyle = {
  padding: "10px",
  textAlign: "left",
  borderBottom: "2px solid #ddd",
};

const tableCellStyle = {
  padding: "10px",
  textAlign: "left",
  borderBottom: "1px solid #ddd",
};

export default ProductsList;
