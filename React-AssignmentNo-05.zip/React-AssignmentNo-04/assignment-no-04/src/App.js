import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ProductProvider } from './context/ProductContext';
import NavBar from './Assignment-04/components/NavBar';
import AddProduct from './Assignment-04/components/AddProduct';
import ProductList from './Assignment-04/components/ProductList';
import ProductDetail from './Assignment-04/components/ProductDetail';

const App = () => {
  return (
    <ProductProvider>
      <Router>
        <NavBar />
        <Routes>
          <Route path="/" element={<h1>Welcome to the Product App</h1>} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/add" element={<AddProduct />} />
          <Route path="/products/:id" element={<ProductDetail />} />
        </Routes>
      </Router>
    </ProductProvider>
  );
};

export default App;