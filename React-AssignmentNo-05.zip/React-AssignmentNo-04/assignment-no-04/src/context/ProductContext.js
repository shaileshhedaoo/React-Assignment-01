import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5173/products').then((response) => {
      setProducts(response.data);
    });
  }, []);

  const addProduct = async (product) => {
    const response = await axios.post('http://localhost:5173/products', product);
    setProducts([...products, response.data]);
  };

  return (
    <ProductContext.Provider value={{ products, addProduct }}>
      {children}
    </ProductContext.Provider>
  );
};
