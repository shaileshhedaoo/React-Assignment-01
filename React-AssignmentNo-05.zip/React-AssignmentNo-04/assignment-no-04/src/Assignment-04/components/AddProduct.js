import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { nanoid } from 'nanoid';
import { useContext } from 'react';
import { ProductContext } from '../../context/ProductContext'; // Corrected import path

const AddProduct = () => {
  const { addProduct } = useContext(ProductContext);

  const formik = useFormik({
    initialValues: {
      productName: '',
      quantity: '',
      price: '',
    },
    validationSchema: Yup.object({
      productName: Yup.string().required('Product Name is required'),
      quantity: Yup.number().required('Quantity is required').positive().integer(),
      price: Yup.number().required('Price is required').positive(),
    }),
    onSubmit: (values, { resetForm }) => {
      addProduct({ id: nanoid(), ...values });
      resetForm();
    },
  });

  return (
    <div style={styles.formContainer}>
      <form onSubmit={formik.handleSubmit} style={styles.productForm}>
        <h2>Add Product</h2>

        <div style={styles.inputGroup}>
          <label htmlFor="productName" style={styles.label}>Product Name: </label>
          <input
            type="text"
            name="productName"
            id="productName"
            placeholder="Enter Product Name"
            value={formik.values.productName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            style={formik.errors.productName && formik.touched.productName ? { ...styles.input, ...styles.inputError } : styles.input}
          />
          {formik.errors.productName && formik.touched.productName && (
            <div style={styles.error}>{formik.errors.productName}</div>
          )}
        </div>

        <div style={styles.inputGroup}>
          <label htmlFor="quantity" style={styles.label}>Quantity: </label>
          <input
            type="number"
            name="quantity"
            id="quantity"
            placeholder="Enter Quantity"
            value={formik.values.quantity}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            style={formik.errors.quantity && formik.touched.quantity ? { ...styles.input, ...styles.inputError } : styles.input}
          />
          {formik.errors.quantity && formik.touched.quantity && (
            <div style={styles.error}>{formik.errors.quantity}</div>
          )}
        </div>

        <div style={styles.inputGroup}>
          <label htmlFor="price" style={styles.label}>Price:</label>
          <input
            type="number"
            name="price"
            id="price"
            placeholder="Enter Price"
            value={formik.values.price}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            style={formik.errors.price && formik.touched.price ? { ...styles.input, ...styles.inputError } : styles.input}
          />
          {formik.errors.price && formik.touched.price && (
            <div style={styles.error}>{formik.errors.price}</div>
          )}
        </div>

        <button type="submit" style={styles.submitButton}>Add Product</button>
      </form>
    </div>
  );
};

const styles = {
  formContainer: {
    width: '100%',
    maxWidth: '600px',
    margin: '2rem auto',
    padding: '1.5rem',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  productForm: {
    display: 'flex',
    flexDirection: 'column',
  },
  inputGroup: {
    marginBottom: '15px',
  },
  label: {
    marginBottom: '5px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
  },
  input: {
    padding: '10px',
    marginBottom: '15px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '16px',
  },
  inputError: {
    borderColor: '#e74c3c',
  },
  error: {
    color: '#e74c3c',
    fontSize: '12px',
    marginTop: '5px',
  },
  submitButton: {
    padding: '12px 20px',
    backgroundColor: '#4caf50',
    color: 'white',
    fontSize: '16px',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  },
};

export default AddProduct;
