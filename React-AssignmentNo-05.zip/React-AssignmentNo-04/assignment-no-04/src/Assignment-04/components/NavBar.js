import React from 'react';
import { Link } from 'react-router-dom';

const NavBar = () => {
  return (
    <nav style={{ display: 'flex', gap: '20px', padding: '10px', backgroundColor: '#f0f0f0' }}>
      <Link to="/">About</Link>
      <Link to="/products">Products</Link>
    </nav>
  );
};

export default NavBar;
