import React from 'react';
import Counter from './components/Counter'; // Corrected path

function App() {
  return (
    <div>
      <Counter />
    </div>
  );
}

export default App;
