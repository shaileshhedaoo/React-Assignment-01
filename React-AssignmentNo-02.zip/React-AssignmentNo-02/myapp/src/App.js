import React from 'react';
import AllProductsPage from './components/AllProductsPage';

function App() {
  return <AllProductsPage />;
}

export default App;
