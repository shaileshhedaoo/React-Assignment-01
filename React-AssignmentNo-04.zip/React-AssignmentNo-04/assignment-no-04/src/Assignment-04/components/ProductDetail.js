import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ProductContext } from '../../context/ProductContext'; // Corrected import path

const ProductDetail = () => {
  const { products } = React.useContext(ProductContext);
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find((product) => product.id === id);

  const confirmView = () => {
    if (window.confirm('Are you sure you want to view the details?')) {
      return true;
    }
    navigate('/products');
    return false;
  };

  const containerStyle = {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
  };

  const headerStyle = {
    textAlign: 'center',
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#333',
  };

  const detailStyle = {
    backgroundColor: '#f9f9f9',
    padding: '15px',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    marginBottom: '20px',
  };

  const textStyle = {
    fontSize: '1.2rem',
    margin: '10px 0',
    color: '#555',
  };

  const buttonStyle = {
    display: 'inline-block',
    backgroundColor: '#007BFF',
    color: '#fff',
    padding: '10px 20px',
    borderRadius: '5px',
    textDecoration: 'none',
    marginTop: '20px',
    textAlign: 'center',
  };

  const buttonHoverStyle = {
    backgroundColor: '#0056b3',
  };

  if (!product) {
    return <p>Product not found</p>;
  }

  return (
    confirmView() && (
      <div style={containerStyle}>
        <h2 style={headerStyle}>{product.productName}</h2>
        <div style={detailStyle}>
          <p style={textStyle}>Quantity: {product.quantity}</p>
          <p style={textStyle}>Price: ${product.price}</p>
        </div>
        <a
          href="/products"
          style={buttonStyle}
          onMouseOver={(e) => e.target.style.backgroundColor = buttonHoverStyle.backgroundColor}
          onMouseOut={(e) => e.target.style.backgroundColor = buttonStyle.backgroundColor}
        >
          Back to Products
        </a>
      </div>
    )
  );
};

export default ProductDetail;
