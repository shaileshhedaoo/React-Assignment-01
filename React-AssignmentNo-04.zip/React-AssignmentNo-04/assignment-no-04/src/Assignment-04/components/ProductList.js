import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { ProductContext } from '../../context/ProductContext'; // Corrected import path

const ProductList = () => {
  const { products } = useContext(ProductContext);

  const containerStyle = {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
  };

  const headerStyle = {
    textAlign: 'center',
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#333',
  };

  const listStyle = {
    listStyleType: 'none',
    padding: '0',
  };

  const itemStyle = {
    backgroundColor: '#f9f9f9',
    margin: '10px 0',
    padding: '15px',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };

  const infoStyle = {
    flexGrow: '1',
  };

  const nameStyle = {
    fontSize: '1.25rem',
    color: '#333',
    fontWeight: 'bold',
  };

  const priceStyle = {
    fontSize: '1.1rem',
    color: '#007BFF',
    margin: '5px 0',
  };

  const quantityStyle = {
    fontSize: '1rem',
    color: '#888',
  };

  const linkStyle = {
    textDecoration: 'none',
    color: '#fff',
    backgroundColor: '#28a745',
    padding: '8px 15px',
    borderRadius: '5px',
    transition: 'background-color 0.3s',
  };

  const linkHoverStyle = {
    backgroundColor: '#218838',
  };

  const noProductsStyle = {
    textAlign: 'center',
    fontSize: '1.2rem',
    color: '#888',
  };

  const addProductLinkContainerStyle = {
    textAlign: 'center',
    marginTop: '20px',
  };

  const addProductLinkStyle = {
    textDecoration: 'none',
    color: '#fff',
    backgroundColor: '#007BFF',
    padding: '10px 20px',
    borderRadius: '5px',
    fontSize: '1.2rem',
  };

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>Products List</h2>
      <ul style={listStyle}>
        {products.length > 0 ? (
          products.map((product) => (
            <li key={product.id} style={itemStyle}>
              <div style={infoStyle}>
                <h3 style={nameStyle}>{product.productName}</h3>
                <p style={priceStyle}>${product.price}</p>
                <p style={quantityStyle}>Qty: {product.quantity}</p>
              </div>
              <Link to={`/products/${product.id}`} style={linkStyle} 
                onMouseOver={(e) => e.target.style.backgroundColor = linkHoverStyle.backgroundColor}
                onMouseOut={(e) => e.target.style.backgroundColor = linkStyle.backgroundColor}>
                View Details
              </Link>
            </li>
          ))
        ) : (
          <p style={noProductsStyle}>No products available.</p>
        )}
      </ul>
      <div style={addProductLinkContainerStyle}>
        <Link to="/add" style={addProductLinkStyle}>Add Product</Link>
      </div>
    </div>
  );
};

export default ProductList;
