import React from 'react';

function About() {
  return (
    <div>
      <h1>About Products</h1>
      <p>This page contains information about our products.</p>
    </div>
  );
}

export default About;
